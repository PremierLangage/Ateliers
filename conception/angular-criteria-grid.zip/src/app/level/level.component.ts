import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Niveau } from '../models/criteria.models';

@Component({
  selector: 'app-level',
  templateUrl: './level.component.html',
  styleUrls: ['./level.component.scss']
})
export class LevelComponent implements OnInit {
  @Input() niveau:Niveau;
  editMode = false;
  saisieDesc = '';

  constructor() { }

  ngOnInit(): void {
  }

  changeEditMode(){
    this.editMode = !this.editMode;
  }

  changeDescription(){
    this.niveau.description = this.saisieDesc;
    this.saisieDesc = '';
  }
    
}
