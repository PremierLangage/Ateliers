import { Component, OnInit, Input } from '@angular/core';
import { Critere } from '../models/criteria.models';

@Component({
  selector: 'app-criteria',
  templateUrl: './criteria.component.html',
  styleUrls: ['./criteria.component.scss']
})

export class CriteriaComponent implements OnInit {
  
  @Input() critere: Critere;
  editMode = false;
  saisieDesc = '';

  constructor() { }

  ngOnInit(): void {

  }

  enableEdit(){
    this.editMode = true;
    this.saisieDesc = this.critere.description;
  }

  disableEdit(){
    this.editMode = false;
  }
  changeDescription(){
    this.critere.description = this.saisieDesc;
  }
}
